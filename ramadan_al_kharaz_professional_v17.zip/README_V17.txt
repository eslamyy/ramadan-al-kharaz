Professional V17
Base: V13 stable.
Includes printing, PDF generation and Android share sheet.
No AndroidX dependency.
Keeps invoices, stock deduction, permissions, WhatsApp QR, archive and backup.
