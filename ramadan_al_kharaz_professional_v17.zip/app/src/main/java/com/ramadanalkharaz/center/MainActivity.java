package com.ramadanalkharaz.center;

import android.app.Activity;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setDefaultTextEncodingName("UTF-8");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private PrintAttributes getPrintAttributes() {
        return new PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setResolution(new PrintAttributes.Resolution("invoice", "invoice", 300, 300))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .build();
    }

    private String safeFileName(String name) {
        String n = name == null ? "" : name.trim();
        if (n.length() == 0) n = "فاتورة_مركز_رمضان_الخراز";
        n = n.replaceAll("[\\\\/:*?\"<>|\\n\\r]+", "_");
        if (!n.toLowerCase().endsWith(".pdf")) n += ".pdf";
        return n;
    }

    private void createAndSharePdf(final String requestedName) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final String fileName = safeFileName(requestedName);
                File dir = new File(getCacheDir(), "shared_invoices");
                if (!dir.exists()) dir.mkdirs();

                final File pdfFile = new File(dir, fileName);
                final PrintDocumentAdapter adapter =
                    webView.createPrintDocumentAdapter(fileName.replace(".pdf", ""));
                final CancellationSignal signal = new CancellationSignal();

                adapter.onLayout(
                    null,
                    getPrintAttributes(),
                    signal,
                    new PrintDocumentAdapter.LayoutResultCallback() {
                        @Override
                        public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                            try {
                                final ParcelFileDescriptor pfd = ParcelFileDescriptor.open(
                                    pdfFile,
                                    ParcelFileDescriptor.MODE_CREATE |
                                    ParcelFileDescriptor.MODE_TRUNCATE |
                                    ParcelFileDescriptor.MODE_READ_WRITE
                                );

                                adapter.onWrite(
                                    new PageRange[]{PageRange.ALL_PAGES},
                                    pfd,
                                    signal,
                                    new PrintDocumentAdapter.WriteResultCallback() {
                                        @Override
                                        public void onWriteFinished(PageRange[] pages) {
                                            try { pfd.close(); } catch (IOException ignored) {}

                                            Uri uri = Uri.parse(
                                                "content://" + getPackageName() +
                                                ".invoiceprovider/" + Uri.encode(fileName)
                                            );

                                            Intent send = new Intent(Intent.ACTION_SEND);
                                            send.setType("application/pdf");
                                            send.putExtra(Intent.EXTRA_STREAM, uri);
                                            send.putExtra(Intent.EXTRA_SUBJECT, fileName);
                                            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                                            Toast.makeText(
                                                MainActivity.this,
                                                "تم إنشاء ملف PDF",
                                                Toast.LENGTH_SHORT
                                            ).show();

                                            startActivity(Intent.createChooser(send, "إرسال الفاتورة"));
                                        }

                                        @Override
                                        public void onWriteFailed(CharSequence error) {
                                            try { pfd.close(); } catch (IOException ignored) {}
                                            Toast.makeText(
                                                MainActivity.this,
                                                "فشل إنشاء PDF",
                                                Toast.LENGTH_LONG
                                            ).show();
                                        }
                                    }
                                );
                            } catch (Exception e) {
                                Toast.makeText(
                                    MainActivity.this,
                                    "خطأ PDF: " + e.getMessage(),
                                    Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                    },
                    null
                );
            }
        });
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void printInvoice() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    PrintManager pm =
                        (PrintManager) getSystemService(Context.PRINT_SERVICE);

                    PrintDocumentAdapter adapter =
                        webView.createPrintDocumentAdapter("فاتورة مركز رمضان الخراز");

                    pm.print(
                        "فاتورة مركز رمضان الخراز",
                        adapter,
                        getPrintAttributes()
                    );
                }
            });
        }

        @JavascriptInterface
        public void shareInvoicePdf(String fileName) {
            createAndSharePdf(fileName);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
