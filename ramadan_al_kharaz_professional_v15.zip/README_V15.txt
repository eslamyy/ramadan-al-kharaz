Ramadan Al Kharaz Center - Professional V15

Built from stable V13.

New:
- Generate the current invoice as a real PDF.
- Editable PDF filename before sharing.
- Suggested filename uses invoice number and customer name.
- Share via Android share sheet: WhatsApp, Telegram, Gmail, Drive, Bluetooth, etc.
- Saves a copy into Android Downloads using MediaStore.
- No AndroidX dependency and no FileProvider dependency.
- Existing native printing from V13 remains available.

All V13 invoice, stock deduction, permissions, QR, backup, archive and branding features retained.
