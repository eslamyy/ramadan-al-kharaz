package com.ramadanalkharaz.center;

import android.app.Activity;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setDefaultTextEncodingName("UTF-8");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private PrintAttributes invoicePrintAttributes() {
        return new PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setResolution(new PrintAttributes.Resolution("invoice", "invoice", 300, 300))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .build();
    }

    private String safeFileName(String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) n = "فاتورة_مركز_رمضان_الخراز";
        n = n.replaceAll("[\\\\/:*?\"<>|\\n\\r]+", "_");
        if (!n.toLowerCase().endsWith(".pdf")) n += ".pdf";
        return n;
    }

    private Uri savePdfToDownloads(File sourceFile, String fileName) throws Exception {
        ContentResolver resolver = getContentResolver();

        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
        values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
        values.put(MediaStore.Downloads.IS_PENDING, 1);

        Uri collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
        Uri uri = resolver.insert(collection, values);
        if (uri == null) throw new IOException("تعذر إنشاء ملف PDF");

        try (FileInputStream in = new FileInputStream(sourceFile);
             OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) throw new IOException("تعذر فتح ملف PDF");
            byte[] buffer = new byte[8192];
            int len;
            while ((len = in.read(buffer)) > 0) {
                out.write(buffer, 0, len);
            }
            out.flush();
        }

        ContentValues done = new ContentValues();
        done.put(MediaStore.Downloads.IS_PENDING, 0);
        resolver.update(uri, done, null, null);

        return uri;
    }

    private void sharePdfUri(Uri uri, String fileName) {
        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType("application/pdf");
        sendIntent.putExtra(Intent.EXTRA_STREAM, uri);
        sendIntent.putExtra(Intent.EXTRA_SUBJECT, fileName);
        sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        startActivity(Intent.createChooser(sendIntent, "إرسال الفاتورة"));
    }

    private void createPdfAndShare(String requestedName) {
        runOnUiThread(() -> {
            final String fileName = safeFileName(requestedName);
            final File tempFile = new File(getCacheDir(), fileName);

            PrintDocumentAdapter adapter =
                webView.createPrintDocumentAdapter(fileName.replace(".pdf", ""));

            PrintAttributes attributes = invoicePrintAttributes();
            CancellationSignal cancellationSignal = new CancellationSignal();

            adapter.onLayout(
                null,
                attributes,
                cancellationSignal,
                new PrintDocumentAdapter.LayoutResultCallback() {
                    @Override
                    public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                        try {
                            final ParcelFileDescriptor pfd = ParcelFileDescriptor.open(
                                tempFile,
                                ParcelFileDescriptor.MODE_CREATE
                                    | ParcelFileDescriptor.MODE_TRUNCATE
                                    | ParcelFileDescriptor.MODE_READ_WRITE
                            );

                            adapter.onWrite(
                                new PageRange[]{PageRange.ALL_PAGES},
                                pfd,
                                cancellationSignal,
                                new PrintDocumentAdapter.WriteResultCallback() {
                                    @Override
                                    public void onWriteFinished(PageRange[] pages) {
                                        try { pfd.close(); } catch (IOException ignored) {}

                                        try {
                                            Uri savedUri = savePdfToDownloads(tempFile, fileName);
                                            Toast.makeText(
                                                MainActivity.this,
                                                "تم إنشاء PDF: " + fileName,
                                                Toast.LENGTH_SHORT
                                            ).show();
                                            sharePdfUri(savedUri, fileName);
                                        } catch (Exception e) {
                                            Toast.makeText(
                                                MainActivity.this,
                                                "تعذر حفظ PDF: " + e.getMessage(),
                                                Toast.LENGTH_LONG
                                            ).show();
                                        }
                                    }

                                    @Override
                                    public void onWriteFailed(CharSequence error) {
                                        try { pfd.close(); } catch (IOException ignored) {}
                                        Toast.makeText(
                                            MainActivity.this,
                                            "فشل إنشاء ملف PDF",
                                            Toast.LENGTH_LONG
                                        ).show();
                                    }

                                    @Override
                                    public void onWriteCancelled() {
                                        try { pfd.close(); } catch (IOException ignored) {}
                                    }
                                }
                            );
                        } catch (Exception e) {
                            Toast.makeText(
                                MainActivity.this,
                                "تعذر إنشاء PDF: " + e.getMessage(),
                                Toast.LENGTH_LONG
                            ).show();
                        }
                    }

                    @Override
                    public void onLayoutFailed(CharSequence error) {
                        Toast.makeText(
                            MainActivity.this,
                            "تعذر تجهيز الفاتورة للمشاركة",
                            Toast.LENGTH_LONG
                        ).show();
                    }
                },
                null
            );
        });
    }

    private class PrintBridge {
        @JavascriptInterface
        public void printInvoice() {
            runOnUiThread(() -> {
                PrintManager printManager =
                    (PrintManager) getSystemService(Context.PRINT_SERVICE);

                String jobName = "فاتورة مركز رمضان الخراز";
                PrintDocumentAdapter adapter =
                    webView.createPrintDocumentAdapter(jobName);

                printManager.print(jobName, adapter, invoicePrintAttributes());
            });
        }

        @JavascriptInterface
        public void shareInvoicePdf(String fileName) {
            createPdfAndShare(fileName);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
