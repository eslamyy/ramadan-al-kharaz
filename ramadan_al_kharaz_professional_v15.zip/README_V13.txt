V13 print fix
- Added native Android PrintManager bridge.
- Print button now opens Android system print dialog.
- A4 color print attributes are requested.
- Existing invoice preview, WhatsApp QR, stock deduction, sale approval and permissions retained.
