package com.ramadanalkharaz.center;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

public class InvoiceShareProvider extends ContentProvider {
    @Override
    public boolean onCreate() {
        return true;
    }

    private File getInvoiceFile(Uri uri) throws FileNotFoundException {
        if (getContext() == null) throw new FileNotFoundException("No context");

        String name = uri.getLastPathSegment();
        if (name == null || name.length() == 0) {
            throw new FileNotFoundException("Missing file name");
        }

        name = new File(name).getName();
        File file = new File(
            new File(getContext().getCacheDir(), "shared_invoices"),
            name
        );

        if (!file.exists()) throw new FileNotFoundException(name);
        return file;
    }

    @Override
    public String getType(Uri uri) {
        return "application/pdf";
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode)
        throws FileNotFoundException {
        return ParcelFileDescriptor.open(
            getInvoiceFile(uri),
            ParcelFileDescriptor.MODE_READ_ONLY
        );
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        MatrixCursor cursor = new MatrixCursor(
            new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}
        );
        try {
            File f = getInvoiceFile(uri);
            cursor.addRow(new Object[]{f.getName(), f.length()});
        } catch (Exception ignored) {}
        return cursor;
    }

    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int update(Uri uri, ContentValues values, String s, String[] a) { return 0; }
    @Override public int delete(Uri uri, String s, String[] a) { return 0; }
}
