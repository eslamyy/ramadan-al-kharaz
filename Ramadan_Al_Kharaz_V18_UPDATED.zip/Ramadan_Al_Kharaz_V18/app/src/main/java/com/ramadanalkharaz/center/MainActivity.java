package com.ramadanalkharaz.center;

import android.app.Activity;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.widget.Toast;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;

import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setDefaultTextEncodingName("UTF-8");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private PrintAttributes getPrintAttributes() {
        return new PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setResolution(new PrintAttributes.Resolution("invoice", "invoice", 300, 300))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .build();
    }

    private String safeFileName(String name) {
        String n = name == null ? "" : name.trim();
        if (n.length() == 0) n = "فاتورة_مركز_رمضان_الخراز";
        n = n.replaceAll("[\\\\/:*?\"<>|\\n\\r]+", "_");
        if (!n.toLowerCase().endsWith(".pdf")) n += ".pdf";
        return n;
    }

    private void sharePdf(File pdfFile, String fileName, boolean whatsappOnly) {
        Uri uri = Uri.parse(
            "content://" + getPackageName() +
            ".invoiceprovider/" + Uri.encode(fileName)
        );

        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("application/pdf");
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_SUBJECT, fileName);
        send.putExtra(Intent.EXTRA_TEXT, "فاتورة من مركز رمضان الخراز");
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        if (!whatsappOnly) {
            startActivity(Intent.createChooser(send, "مشاركة الفاتورة PDF"));
            return;
        }

        // Try normal WhatsApp first, then WhatsApp Business.
        try {
            Intent wa = new Intent(send);
            wa.setPackage("com.whatsapp");
            startActivity(wa);
        } catch (ActivityNotFoundException first) {
            try {
                Intent wab = new Intent(send);
                wab.setPackage("com.whatsapp.w4b");
                startActivity(wab);
            } catch (ActivityNotFoundException second) {
                Toast.makeText(
                    MainActivity.this,
                    "واتساب غير مثبت. سيتم فتح قائمة المشاركة.",
                    Toast.LENGTH_SHORT
                ).show();
                startActivity(Intent.createChooser(send, "مشاركة الفاتورة PDF"));
            }
        }
    }

    private void createAndSharePdf(final String requestedName, final boolean whatsappOnly) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final String fileName = safeFileName(requestedName);

                final File dir = new File(getCacheDir(), "shared_invoices");
                if (!dir.exists() && !dir.mkdirs()) {
                    Toast.makeText(
                        MainActivity.this,
                        "تعذر إنشاء مجلد الفواتير",
                        Toast.LENGTH_LONG
                    ).show();
                    return;
                }

                final File pdfFile = new File(dir, fileName);

                webView.evaluateJavascript(
                    "(function(){"
                    + "document.querySelectorAll('.no-print,.bottom-nav').forEach(function(e){"
                    + "e.setAttribute('data-v17-old-display',e.style.display||'');"
                    + "e.style.display='none';"
                    + "});"
                    + "})();",
                    value -> webView.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            PdfDocument document = new PdfDocument();

                            try {
                                final int pageWidth = 595;
                                final int pageHeight = 842;

                                PdfDocument.PageInfo pageInfo =
                                    new PdfDocument.PageInfo.Builder(
                                        pageWidth,
                                        pageHeight,
                                        1
                                    ).create();

                                PdfDocument.Page page = document.startPage(pageInfo);
                                Canvas canvas = page.getCanvas();

                                int contentWidth = Math.max(1, webView.getWidth());
                                int contentHeight = Math.max(1, webView.getContentHeight());

                                float scaleX = (float) pageWidth / (float) contentWidth;
                                float scaleY = (float) pageHeight / (float) contentHeight;
                                float scale = Math.min(scaleX, scaleY);

                                canvas.save();
                                canvas.scale(scale, scale);
                                webView.draw(canvas);
                                canvas.restore();

                                document.finishPage(page);

                                FileOutputStream fos = new FileOutputStream(pdfFile);
                                document.writeTo(fos);
                                fos.flush();
                                fos.close();

                                Toast.makeText(
                                    MainActivity.this,
                                    "تم إنشاء ملف PDF",
                                    Toast.LENGTH_SHORT
                                ).show();

                                sharePdf(pdfFile, fileName, whatsappOnly);

                            } catch (Exception e) {
                                Toast.makeText(
                                    MainActivity.this,
                                    "خطأ PDF: " + e.getMessage(),
                                    Toast.LENGTH_LONG
                                ).show();
                            } finally {
                                try {
                                    document.close();
                                } catch (Exception ignored) {}

                                webView.evaluateJavascript(
                                    "(function(){"
                                    + "document.querySelectorAll('[data-v17-old-display]').forEach(function(e){"
                                    + "e.style.display=e.getAttribute('data-v17-old-display')||'';"
                                    + "e.removeAttribute('data-v17-old-display');"
                                    + "});"
                                    + "})();",
                                    null
                                );
                            }
                        }
                    }, 250)
                );
            }
        });
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void printInvoice() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    PrintManager pm =
                        (PrintManager) getSystemService(Context.PRINT_SERVICE);

                    PrintDocumentAdapter adapter =
                        webView.createPrintDocumentAdapter("فاتورة مركز رمضان الخراز");

                    pm.print(
                        "فاتورة مركز رمضان الخراز",
                        adapter,
                        getPrintAttributes()
                    );
                }
            });
        }

        @JavascriptInterface
        public void shareInvoicePdf(String fileName) {
            createAndSharePdf(fileName, false);
        }

        @JavascriptInterface
        public void shareInvoicePdfToWhatsApp(String fileName) {
            createAndSharePdf(fileName, true);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
