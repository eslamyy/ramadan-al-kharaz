V18 Update 18.1
- Added invoice address: بنغازي – السلماني الشرقي – مقابل البريد
- Improved vehicle-brand logo row using existing KIA/Hyundai/Toyota/Nissan SVG assets
- Added document type: فاتورة بيع / عرض سعر
- Added payment method: كاش / مصرفي
- Quote path does not deduct stock; it is saved without inventory deduction
- Existing V18 functions retained, including PDF/WhatsApp sharing, stock, external warehouse, backup and permissions
