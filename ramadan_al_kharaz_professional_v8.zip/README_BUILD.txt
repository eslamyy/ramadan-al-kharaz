Ramadan Al Kharaz Center - Professional V8
- Fixed + إضافة بند in invoice.
- Approved Model 1 invoice layout retained and refined.
- Added Toyota / Nissan / Hyundai / Kia marks beside invoice branding.
- Added approved login background.
- Added user login and manager-controlled permissions.
- Worker name remains internal and is not printed on customer invoice.
- Invoice numbers remain sequential starting from 1.
- Customer invoice archive, inventory-to-invoice, OEM number and backup retained.
Default first login: admin / 1234
