import os
import threading

_server_started = False

def start_server(files_dir):
    global _server_started

    if _server_started:
        return "already_started"

    import sales_system_final as system

    # Store the database in Android's private writable app directory.
    system.DATABASE = os.path.join(files_dir, "sales_full.db")
    system.init_db()

    def run():
        system.app.run(
            host="127.0.0.1",
            port=5000,
            debug=False,
            use_reloader=False,
            threaded=True
        )

    thread = threading.Thread(target=run, daemon=True)
    thread.start()
    _server_started = True
    return "started"
