Android project for مركز رمضان الخراز.
Built with Android WebView + Chaquopy + Flask.
