package com.debtmanager.clean;

import android.app.Activity;
import android.app.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_EXPORT = 1001;
    private static final int REQ_IMPORT_JSON = 1002;
    private static final int REQ_IMPORT_SQLITE = 1003;
    private WebView webView;
    private String pendingExportJson = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("tel:")) {
                    startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse(url)));
                    return true;
                }
                if (url.startsWith("https://wa.me/") || url.startsWith("whatsapp:")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "تعذر فتح واتساب", Toast.LENGTH_SHORT).show(); }
                    return true;
                }
                return false;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void exportBackup(String json, String suggestedName) {
            pendingExportJson = json == null ? "" : json;
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE, suggestedName == null || suggestedName.isEmpty() ? "debt_backup.json" : suggestedName);
            startActivityForResult(i, REQ_EXPORT);
        }

        @JavascriptInterface
        public void importBackup() {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/json");
            startActivityForResult(i, REQ_IMPORT_JSON);
        }

        @JavascriptInterface
        public void importLegacySqlite() {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_IMPORT_SQLITE);
        }

        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                pm.print("كشف حساب - إدارة الديون", webView.createPrintDocumentAdapter("DebtManager"), null);
            });
        }

        @JavascriptInterface
        public void shareText(String text) {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(share, "مشاركة"));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_EXPORT) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    out.write(pendingExportJson.getBytes(StandardCharsets.UTF_8));
                }
                Toast.makeText(this, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_SHORT).show();
            } else if (requestCode == REQ_IMPORT_JSON) {
                String json = readAll(uri);
                String quoted = JSONObject.quote(json);
                webView.evaluateJavascript("window.DebtApp.importBackupText(" + quoted + ")", null);
            } else if (requestCode == REQ_IMPORT_SQLITE) {
                JSONObject payload = importLegacyDb(uri);
                String quoted = JSONObject.quote(payload.toString());
                webView.evaluateJavascript("window.DebtApp.importLegacyText(" + quoted + ")", null);
            }
        } catch (Exception e) {
            Toast.makeText(this, "تعذر إكمال العملية: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String readAll(Uri uri) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(uri), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private JSONObject importLegacyDb(Uri uri) throws Exception {
        File tmp = new File(getCacheDir(), "legacy_debts.db");
        try (InputStream in = getContentResolver().openInputStream(uri); FileOutputStream out = new FileOutputStream(tmp)) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        SQLiteDatabase db = SQLiteDatabase.openDatabase(tmp.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
        JSONArray customers = new JSONArray();
        JSONArray txs = new JSONArray();
        try (Cursor c = db.rawQuery("SELECT id,name,phone,address,notes,created_at FROM customers ORDER BY id", null)) {
            while (c.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("id", c.getLong(0)); o.put("name", safe(c,1)); o.put("phone", safe(c,2));
                o.put("address", safe(c,3)); o.put("notes", safe(c,4)); o.put("createdAt", safe(c,5));
                customers.put(o);
            }
        }
        try (Cursor c = db.rawQuery("SELECT id,customer_id,tx_type,amount,description,tx_date,due_date,payment_method,created_at FROM transactions ORDER BY id", null)) {
            while (c.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("id", c.getLong(0)); o.put("customerId", c.getLong(1)); o.put("type", safe(c,2));
                o.put("amount", c.getDouble(3)); o.put("description", safe(c,4)); o.put("date", safe(c,5));
                o.put("dueDate", safe(c,6)); o.put("paymentMethod", safe(c,7)); o.put("createdAt", safe(c,8));
                txs.put(o);
            }
        }
        db.close();
        JSONObject result = new JSONObject();
        result.put("customers", customers); result.put("transactions", txs); result.put("source", "legacy-sqlite");
        tmp.delete();
        return result;
    }

    private String safe(Cursor c, int idx) { return c.isNull(idx) ? "" : c.getString(idx); }

    @Override
    public void onBackPressed() {
        webView.evaluateJavascript("window.DebtApp && window.DebtApp.handleBack ? window.DebtApp.handleBack() : false", value -> {
            if ("false".equals(value)) super.onBackPressed();
        });
    }
}
