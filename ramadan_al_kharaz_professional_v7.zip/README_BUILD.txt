Ramadan Al Kharaz Center - Professional V7

Updates:
- Invoice number now starts at 1 and automatically increments sequentially.
- Invoice branding updated to: مركز رمضان الخراز للميكانيكا الحديثة.
- Added WhatsApp 0910284368 and phone 0925886239 to invoice.
- Added engine service warranty: 1000 km / 625 miles.
- Existing invoice preview, customer invoice archive, worker internal field, inventory-to-invoice, OEM, backup and warehouse features retained.
