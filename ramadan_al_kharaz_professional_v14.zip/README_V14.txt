V14
- Creates the current invoice as a real PDF file.
- Editable PDF filename before sharing.
- Suggested filename uses invoice number and customer name.
- Android share sheet supports WhatsApp and other installed apps.
- Existing Android printing remains available.
