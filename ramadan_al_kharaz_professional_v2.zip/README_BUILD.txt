Ramadan Al Kharaz Center - Clean V1

Fresh Android project built from scratch.
Core modules:
- Sales
- Main inventory
- External warehouse
- Transfers between main and external warehouse
- Monthly / yearly / manual full stocktake
- Spare-parts lookup by OEM / barcode / alternate code
- Quick reports
- Offline local data storage on device

Build command:
gradle :app:assembleDebug
