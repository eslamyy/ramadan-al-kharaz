package com.ramadanalkharaz.center;

import android.app.Activity;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.widget.Toast;
import android.graphics.Canvas;
import android.graphics.Picture;
import android.graphics.pdf.PdfDocument;

import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setDefaultTextEncodingName("UTF-8");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private PrintAttributes.MediaSize getMediaSize(String paper) {
        if ("A5".equalsIgnoreCase(paper)) return PrintAttributes.MediaSize.ISO_A5;
        if ("LETTER".equalsIgnoreCase(paper)) return PrintAttributes.MediaSize.NA_LETTER;
        if ("LEGAL".equalsIgnoreCase(paper)) return PrintAttributes.MediaSize.NA_LEGAL;
        return PrintAttributes.MediaSize.ISO_A4;
    }

    private PrintAttributes getPrintAttributes(String paper) {
        return new PrintAttributes.Builder()
            .setMediaSize(getMediaSize(paper))
            .setResolution(new PrintAttributes.Resolution("invoice", "invoice", 300, 300))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .build();
    }

    private int[] getPdfPagePoints(String paper) {
        if ("A5".equalsIgnoreCase(paper)) return new int[]{420, 595};
        if ("LETTER".equalsIgnoreCase(paper)) return new int[]{612, 792};
        if ("LEGAL".equalsIgnoreCase(paper)) return new int[]{612, 1008};
        return new int[]{595, 842};
    }

    private String safeFileName(String name) {
        String n = name == null ? "" : name.trim();
        if (n.length() == 0) n = "فاتورة_مركز_رمضان_الخراز";
        n = n.replaceAll("[\\\\/:*?\"<>|\\n\\r]+", "_");
        if (!n.toLowerCase().endsWith(".pdf")) n += ".pdf";
        return n;
    }

    private void sharePdf(File pdfFile, String fileName, boolean whatsappOnly) {
        Uri uri = Uri.parse(
            "content://" + getPackageName() +
            ".invoiceprovider/" + Uri.encode(fileName)
        );

        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("application/pdf");
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.putExtra(Intent.EXTRA_SUBJECT, fileName);
        send.putExtra(Intent.EXTRA_TEXT, "فاتورة من مركز رمضان الخراز");
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        if (!whatsappOnly) {
            startActivity(Intent.createChooser(send, "مشاركة الفاتورة PDF"));
            return;
        }

        // Try normal WhatsApp first, then WhatsApp Business.
        try {
            Intent wa = new Intent(send);
            wa.setPackage("com.whatsapp");
            startActivity(wa);
        } catch (ActivityNotFoundException first) {
            try {
                Intent wab = new Intent(send);
                wab.setPackage("com.whatsapp.w4b");
                startActivity(wab);
            } catch (ActivityNotFoundException second) {
                Toast.makeText(
                    MainActivity.this,
                    "واتساب غير مثبت. سيتم فتح قائمة المشاركة.",
                    Toast.LENGTH_SHORT
                ).show();
                startActivity(Intent.createChooser(send, "مشاركة الفاتورة PDF"));
            }
        }
    }

    private void createAndSharePdf(final String requestedName, final boolean whatsappOnly, final String paper) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final String fileName = safeFileName(requestedName);

                final File dir = new File(getCacheDir(), "shared_invoices");
                if (!dir.exists() && !dir.mkdirs()) {
                    Toast.makeText(
                        MainActivity.this,
                        "تعذر إنشاء مجلد الفواتير",
                        Toast.LENGTH_LONG
                    ).show();
                    return;
                }

                final File pdfFile = new File(dir, fileName);

                webView.evaluateJavascript(
                    "(function(){"
                    + "document.querySelectorAll('header,.no-print,.bottom-nav,.app-bottom-nav,nav.bottom-nav,main>section:not(#invoicePreviewPage)').forEach(function(e){"
                    + "e.setAttribute('data-pdf-old-display',e.style.display||'');"
                    + "e.style.display='none';"
                    + "});"
                    + "var m=document.querySelector('main');if(m){m.setAttribute('data-pdf-old-style',m.getAttribute('style')||'');m.style.cssText='margin:0!important;padding:0!important;width:100%!important;max-width:none!important;';}"
                    + "var s=document.getElementById('invoicePreviewPage');if(s){s.setAttribute('data-pdf-old-style',s.getAttribute('style')||'');s.style.cssText='display:block!important;margin:0!important;padding:0!important;overflow:visible!important;';}"
                    + "var w=document.querySelector('#invoicePreviewPage .invoice-preview-wrap');if(w){w.setAttribute('data-pdf-old-style',w.getAttribute('style')||'');w.style.cssText='margin:0!important;padding:0!important;background:#fff!important;overflow:visible!important;';}"
                    + "var p=document.getElementById('invoicePreviewPaper');if(p){p.setAttribute('data-pdf-old-style',p.getAttribute('style')||'');p.style.cssText+='transform:none!important;transform-origin:top left!important;margin:0!important;box-shadow:none!important;min-height:auto!important;';}"
                    + "window.scrollTo(0,0);"
                    + "var q=document.getElementById('invoicePreviewPaper');"
                    + "if(q){var r=q.getBoundingClientRect();window.__invoiceCrop=(r.top+window.scrollY)+','+r.height+','+r.width;}"
                    + "else{window.__invoiceCrop='0,'+document.body.scrollHeight+','+document.body.scrollWidth;}"
                    + "})();",
                    value -> webView.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            PdfDocument document = new PdfDocument();

                            try {
                                final int[] pagePoints = getPdfPagePoints(paper);
                                final int pageWidth = pagePoints[0];
                                final int pageHeight = pagePoints[1];

                                PdfDocument.PageInfo pageInfo =
                                    new PdfDocument.PageInfo.Builder(
                                        pageWidth,
                                        pageHeight,
                                        1
                                    ).create();

                                PdfDocument.Page page = document.startPage(pageInfo);
                                Canvas canvas = page.getCanvas();

                                // Crop the PDF to the invoice paper itself. Drawing the whole
                                // WebView used to include the hidden page/preview whitespace
                                // above the invoice on shared copies.
                                float cropTop = 0f;
                                float contentWidth = Math.max(1, webView.getWidth());
                                float contentHeight = Math.max(1, webView.getContentHeight());
                                try {
                                    String crop = value == null ? "" : value.replace("\\", "").replace("\"", "");
                                    String[] parts = crop.split(",");
                                    if (parts.length >= 3) {
                                        cropTop = Math.max(0f, Float.parseFloat(parts[0]));
                                        contentHeight = Math.max(1f, Float.parseFloat(parts[1]));
                                        contentWidth = Math.max(1f, Float.parseFloat(parts[2]));
                                    }
                                } catch (Exception ignored) {}

                                float scaleX = (float) pageWidth / contentWidth;
                                float scaleY = (float) pageHeight / contentHeight;
                                float scale = Math.min(scaleX, scaleY);

                                canvas.save();
                                canvas.scale(scale, scale);
                                canvas.translate(0, -cropTop);
                                Picture fullPage = webView.capturePicture();
                                if (fullPage != null) fullPage.draw(canvas);
                                else webView.draw(canvas);
                                canvas.restore();

                                document.finishPage(page);

                                FileOutputStream fos = new FileOutputStream(pdfFile);
                                document.writeTo(fos);
                                fos.flush();
                                fos.close();

                                Toast.makeText(
                                    MainActivity.this,
                                    "تم إنشاء ملف PDF",
                                    Toast.LENGTH_SHORT
                                ).show();

                                sharePdf(pdfFile, fileName, whatsappOnly);

                            } catch (Exception e) {
                                Toast.makeText(
                                    MainActivity.this,
                                    "خطأ PDF: " + e.getMessage(),
                                    Toast.LENGTH_LONG
                                ).show();
                            } finally {
                                try {
                                    document.close();
                                } catch (Exception ignored) {}

                                webView.evaluateJavascript(
                                    "(function(){"
                                    + "document.querySelectorAll('[data-pdf-old-display]').forEach(function(e){e.style.display=e.getAttribute('data-pdf-old-display')||'';e.removeAttribute('data-pdf-old-display');});"
                                    + "document.querySelectorAll('[data-pdf-old-style]').forEach(function(e){var x=e.getAttribute('data-pdf-old-style');if(x)e.setAttribute('style',x);else e.removeAttribute('style');e.removeAttribute('data-pdf-old-style');});"
                                    + "})();",
                                    null
                                );
                            }
                        }
                    }, 250)
                );
            }
        });
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void printInvoice(final String paper) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    PrintManager pm =
                        (PrintManager) getSystemService(Context.PRINT_SERVICE);

                    PrintDocumentAdapter adapter =
                        webView.createPrintDocumentAdapter("فاتورة مركز رمضان الخراز");

                    pm.print(
                        "فاتورة مركز رمضان الخراز",
                        adapter,
                        getPrintAttributes(paper)
                    );
                }
            });
        }

        @JavascriptInterface
        public void shareInvoicePdf(String fileName, String paper) {
            createAndSharePdf(fileName, false, paper);
        }

        @JavascriptInterface
        public void shareInvoicePdfToWhatsApp(String fileName, String paper) {
            createAndSharePdf(fileName, true, paper);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
