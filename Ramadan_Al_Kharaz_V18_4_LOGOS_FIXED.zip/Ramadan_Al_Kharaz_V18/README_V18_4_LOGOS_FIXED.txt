V18.4
- Fixed invoice vehicle logo sizing/alignment.
- Preserved aspect ratio.
- Removed any visible 2026 labels.
- No other system behavior changed.
