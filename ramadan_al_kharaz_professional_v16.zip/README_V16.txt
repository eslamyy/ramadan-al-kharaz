Ramadan Al Kharaz Center - Professional V16

Base: stable V13.

New:
- PDF invoice sharing through the Android share sheet.
- WhatsApp and other installed apps can receive the PDF.
- Editable PDF filename before sharing.
- Suggested filename uses invoice number + customer name.
- Uses a native ContentProvider included in the app.
- No AndroidX dependency.
- Existing V13 printing remains intact.
- Existing invoices, stock deduction, permissions, QR, archive, backup and branding remain intact.
