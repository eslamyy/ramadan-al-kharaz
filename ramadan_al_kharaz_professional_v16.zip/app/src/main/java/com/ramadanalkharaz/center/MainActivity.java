package com.ramadanalkharaz.center;

import android.app.Activity;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setDefaultTextEncodingName("UTF-8");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private PrintAttributes invoicePrintAttributes() {
        return new PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setResolution(new PrintAttributes.Resolution("invoice", "invoice", 300, 300))
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
            .build();
    }

    private String safeFileName(String name) {
        String n = name == null ? "" : name.trim();
        if (n.length() == 0) {
            n = "فاتورة_مركز_رمضان_الخراز";
        }

        n = n.replace('\\', '_')
             .replace('/', '_')
             .replace(':', '_')
             .replace('*', '_')
             .replace('?', '_')
             .replace('"', '_')
             .replace('<', '_')
             .replace('>', '_')
             .replace('|', '_')
             .replace('\n', '_')
             .replace('\r', '_');

        if (!n.toLowerCase().endsWith(".pdf")) {
            n = n + ".pdf";
        }
        return n;
    }

    private void sharePdf(File pdfFile, String fileName) {
        Uri uri = Uri.parse(
            "content://" + getPackageName() + ".invoiceprovider/" + Uri.encode(fileName)
        );

        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType("application/pdf");
        sendIntent.putExtra(Intent.EXTRA_STREAM, uri);
        sendIntent.putExtra(Intent.EXTRA_SUBJECT, fileName);
        sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        startActivity(Intent.createChooser(sendIntent, "إرسال الفاتورة"));
    }

    private void createPdfAndShare(final String requestedName) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final String fileName = safeFileName(requestedName);
                final File shareDir = new File(getCacheDir(), "shared_invoices");

                if (!shareDir.exists() && !shareDir.mkdirs()) {
                    Toast.makeText(
                        MainActivity.this,
                        "تعذر إنشاء مجلد الفواتير",
                        Toast.LENGTH_LONG
                    ).show();
                    return;
                }

                final File pdfFile = new File(shareDir, fileName);
                final PrintDocumentAdapter adapter =
                    webView.createPrintDocumentAdapter(fileName.replace(".pdf", ""));

                final PrintAttributes attributes = invoicePrintAttributes();
                final CancellationSignal signal = new CancellationSignal();

                adapter.onLayout(
                    null,
                    attributes,
                    signal,
                    new PrintDocumentAdapter.LayoutResultCallback() {
                        @Override
                        public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                            try {
                                final ParcelFileDescriptor pfd =
                                    ParcelFileDescriptor.open(
                                        pdfFile,
                                        ParcelFileDescriptor.MODE_CREATE
                                            | ParcelFileDescriptor.MODE_TRUNCATE
                                            | ParcelFileDescriptor.MODE_READ_WRITE
                                    );

                                adapter.onWrite(
                                    new PageRange[] { PageRange.ALL_PAGES },
                                    pfd,
                                    signal,
                                    new PrintDocumentAdapter.WriteResultCallback() {
                                        @Override
                                        public void onWriteFinished(PageRange[] pages) {
                                            try {
                                                pfd.close();
                                            } catch (IOException ignored) {
                                            }

                                            Toast.makeText(
                                                MainActivity.this,
                                                "تم إنشاء ملف PDF",
                                                Toast.LENGTH_SHORT
                                            ).show();

                                            sharePdf(pdfFile, fileName);
                                        }

                                        @Override
                                        public void onWriteFailed(CharSequence error) {
                                            try {
                                                pfd.close();
                                            } catch (IOException ignored) {
                                            }

                                            Toast.makeText(
                                                MainActivity.this,
                                                "فشل إنشاء ملف PDF",
                                                Toast.LENGTH_LONG
                                            ).show();
                                        }

                                        @Override
                                        public void onWriteCancelled() {
                                            try {
                                                pfd.close();
                                            } catch (IOException ignored) {
                                            }
                                        }
                                    }
                                );
                            } catch (Exception e) {
                                Toast.makeText(
                                    MainActivity.this,
                                    "تعذر إنشاء PDF: " + e.getMessage(),
                                    Toast.LENGTH_LONG
                                ).show();
                            }
                        }

                        @Override
                        public void onLayoutFailed(CharSequence error) {
                            Toast.makeText(
                                MainActivity.this,
                                "تعذر تجهيز الفاتورة للمشاركة",
                                Toast.LENGTH_LONG
                            ).show();
                        }
                    },
                    null
                );
            }
        });
    }

    private class PrintBridge {
        @JavascriptInterface
        public void printInvoice() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    PrintManager printManager =
                        (PrintManager) getSystemService(Context.PRINT_SERVICE);

                    String jobName = "فاتورة مركز رمضان الخراز";
                    PrintDocumentAdapter adapter =
                        webView.createPrintDocumentAdapter(jobName);

                    printManager.print(
                        jobName,
                        adapter,
                        invoicePrintAttributes()
                    );
                }
            });
        }

        @JavascriptInterface
        public void shareInvoicePdf(String fileName) {
            createPdfAndShare(fileName);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
