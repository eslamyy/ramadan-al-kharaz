package com.ramadanalkharaz.center;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

public class InvoiceShareProvider extends ContentProvider {

    @Override
    public boolean onCreate() {
        return true;
    }

    private File resolveFile(Uri uri) throws FileNotFoundException {
        if (getContext() == null) {
            throw new FileNotFoundException("No context");
        }

        String fileName = uri.getLastPathSegment();
        if (fileName == null || fileName.length() == 0) {
            throw new FileNotFoundException("Missing file name");
        }

        // Prevent path traversal.
        fileName = new File(fileName).getName();

        File dir = new File(getContext().getCacheDir(), "shared_invoices");
        File file = new File(dir, fileName);

        if (!file.exists()) {
            throw new FileNotFoundException(fileName);
        }
        return file;
    }

    @Override
    public String getType(Uri uri) {
        return "application/pdf";
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode)
        throws FileNotFoundException {

        File file = resolveFile(uri);
        return ParcelFileDescriptor.open(
            file,
            ParcelFileDescriptor.MODE_READ_ONLY
        );
    }

    @Override
    public Cursor query(
        Uri uri,
        String[] projection,
        String selection,
        String[] selectionArgs,
        String sortOrder
    ) {
        try {
            File file = resolveFile(uri);

            MatrixCursor cursor = new MatrixCursor(
                new String[] {
                    OpenableColumns.DISPLAY_NAME,
                    OpenableColumns.SIZE
                }
            );

            cursor.addRow(
                new Object[] {
                    file.getName(),
                    file.length()
                }
            );

            return cursor;
        } catch (Exception e) {
            return new MatrixCursor(
                new String[] {
                    OpenableColumns.DISPLAY_NAME,
                    OpenableColumns.SIZE
                }
            );
        }
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(
        Uri uri,
        ContentValues values,
        String selection,
        String[] selectionArgs
    ) {
        return 0;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }
}
