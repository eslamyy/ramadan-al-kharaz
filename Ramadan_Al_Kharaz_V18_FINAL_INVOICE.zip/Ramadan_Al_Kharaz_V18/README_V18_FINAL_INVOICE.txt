V18.3 Final Approved Invoice
- Approved A4 invoice retained.
- No 2026 text under vehicle logos.
- Bottom navigation hidden in invoice preview/print/PDF.
- Professional table numbering including 10, 11 and beyond.
- Existing V18 functions retained.
