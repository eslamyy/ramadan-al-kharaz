Ramadan Al Kharaz Center - Professional V3

Changes:
- Added working local backup and restore screen.
- Added backup shortcut to home and bottom navigation.
- Improved text contrast: white text on dark cards, black text on light notices.
- Added visible Android launcher icon based on center branding.
- Keeps OEM original part number support, inventory, external warehouse, monthly/yearly stocktake, sales and reports.
