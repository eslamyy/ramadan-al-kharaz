V18.10
- Added paper size selector: A4, A5, Letter, Legal.
- Added equal side-margin selector: 5mm, 7mm, 10mm.
- Invoice is automatically centered on the selected page.
- Android print dialog receives the selected paper size.
- Shared PDF uses the selected paper dimensions.
- All V18.9 stock/warehouse alerts, search, and backup features remain.
- Existing applicationId and localStorage keys preserved.
