V18.7 SEARCH UPDATE
- Added instant search to main inventory.
- Search: product name, OEM, internal code, barcode, alternate/Cross Reference, supplier.
- Added Clear Search and Show All controls.
- Improved external warehouse search with barcode and alternate number.
- Preserves the same applicationId and localStorage keys, so existing installed data remains intact when installed as an update.
