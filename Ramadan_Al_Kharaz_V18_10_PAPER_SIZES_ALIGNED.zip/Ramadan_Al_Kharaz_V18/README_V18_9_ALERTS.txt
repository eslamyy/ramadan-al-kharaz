V18.9 STOCK ALERTS
- Main inventory: items at or below minimum alert are shown with a red border and alert badge.
- External warehouse: items at or below minimum alert are shown with a red border and alert badge.
- Visible summary panel shows number of low-stock items.
- Search and backup features from V18.8 remain included.
- Same applicationId and existing localStorage keys preserved.
