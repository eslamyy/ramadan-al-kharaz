Ramadan Al Kharaz Center - Professional V9

Fixes:
- Toyota, Nissan, Hyundai and Kia are now graphical emblem images in the invoice, not plain written badges.
- Fixed adding saved inventory items to the invoice.
- Added stock search + selectable saved-item list.
- Selecting an item transfers its name, OEM number and selling price into the invoice.
- Displays current available quantity before adding.
- Keeps manual/service line button.
- Prevents saving a quantity greater than available stock.
- All V8 login, permissions, invoice numbering, customer invoice archive, backup and branding features retained.
