V18.5 FINAL APPROVED
- Final approved invoice layout.
- Removed KIA, Hyundai, Nissan and Toyota logos from invoice.
- Uses approved Ramadan Al Kharaz Center logo.
- Preserves existing V18 functions.
- Bottom app navigation is hidden in print/PDF.
