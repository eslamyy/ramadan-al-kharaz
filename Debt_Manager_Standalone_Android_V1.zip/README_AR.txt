برنامج إدارة الديون - نسخة Android مستقلة

هذه النسخة تشغّل Flask محلياً داخل التطبيق عبر Chaquopy وتعرضه داخل WebView.
البيانات تحفظ في مساحة التطبيق الداخلية في ملف debts.db.

للبناء عبر GitHub Actions:
1) ارفع محتويات هذا المشروع إلى مستودع GitHub.
2) افتح Actions.
3) شغّل Build Debt Manager APK.
4) نزّل Artifact باسم Debt-Manager-Standalone-APK.
