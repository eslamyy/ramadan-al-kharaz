from flask import Flask, render_template, request, redirect, url_for, flash, send_file
import sqlite3
from pathlib import Path
from datetime import datetime
import shutil
import os

app = Flask(__name__)
app.secret_key = "debt-manager-local-secret"
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("DEBT_APP_DATA_DIR", str(BASE_DIR)))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "debts.db"
BACKUP_DIR = DATA_DIR / "backups"
BACKUP_DIR.mkdir(parents=True, exist_ok=True)


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        address TEXT,
        notes TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        tx_type TEXT NOT NULL CHECK(tx_type IN ('debt','payment')),
        amount REAL NOT NULL CHECK(amount > 0),
        description TEXT,
        tx_date TEXT NOT NULL,
        due_date TEXT,
        payment_method TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    );
    """)
    conn.commit()
    conn.close()


def customer_balance(conn, customer_id):
    row = conn.execute("""
        SELECT
            COALESCE(SUM(CASE WHEN tx_type='debt' THEN amount ELSE 0 END),0) AS debts,
            COALESCE(SUM(CASE WHEN tx_type='payment' THEN amount ELSE 0 END),0) AS payments
        FROM transactions WHERE customer_id=?
    """, (customer_id,)).fetchone()
    return float(row["debts"]) - float(row["payments"])


def get_customer_or_404(conn, customer_id):
    return conn.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()


@app.route("/")
def dashboard():
    conn = get_db()
    stats = conn.execute("""
        SELECT
            (SELECT COUNT(*) FROM customers) AS customers_count,
            COALESCE(SUM(CASE WHEN tx_type='debt' THEN amount ELSE 0 END),0) AS total_debts,
            COALESCE(SUM(CASE WHEN tx_type='payment' THEN amount ELSE 0 END),0) AS total_payments
        FROM transactions
    """).fetchone()

    rows = conn.execute("""
        SELECT c.id, c.name, c.phone,
               COALESCE(SUM(CASE WHEN t.tx_type='debt' THEN t.amount ELSE 0 END),0) AS debts,
               COALESCE(SUM(CASE WHEN t.tx_type='payment' THEN t.amount ELSE 0 END),0) AS payments
        FROM customers c LEFT JOIN transactions t ON t.customer_id=c.id
        GROUP BY c.id ORDER BY (debts-payments) DESC, c.name LIMIT 8
    """).fetchall()

    active_count = conn.execute("""
        SELECT COUNT(*) FROM (
          SELECT c.id,
          COALESCE(SUM(CASE WHEN t.tx_type='debt' THEN t.amount ELSE 0 END),0)-
          COALESCE(SUM(CASE WHEN t.tx_type='payment' THEN t.amount ELSE 0 END),0) balance
          FROM customers c LEFT JOIN transactions t ON t.customer_id=c.id
          GROUP BY c.id HAVING balance > 0.009
        )
    """).fetchone()[0]
    conn.close()

    total_debts = float(stats["total_debts"] or 0)
    total_payments = float(stats["total_payments"] or 0)
    return render_template("dashboard.html",
        customers_count=stats["customers_count"] or 0,
        active_count=active_count,
        total_debts=total_debts,
        total_payments=total_payments,
        remaining=total_debts-total_payments,
        rows=rows)


@app.route("/customers")
def customers():
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "all")
    conn = get_db()
    params = []
    where_parts = []
    if q:
        where_parts.append("(c.name LIKE ? OR c.phone LIKE ? OR c.address LIKE ?)")
        params += [f"%{q}%", f"%{q}%", f"%{q}%"]
    where = ("WHERE " + " AND ".join(where_parts)) if where_parts else ""

    rows = conn.execute(f"""
        SELECT c.*,
               COALESCE(SUM(CASE WHEN t.tx_type='debt' THEN t.amount ELSE 0 END),0) AS debts,
               COALESCE(SUM(CASE WHEN t.tx_type='payment' THEN t.amount ELSE 0 END),0) AS payments
        FROM customers c LEFT JOIN transactions t ON t.customer_id=c.id
        {where}
        GROUP BY c.id ORDER BY c.name
    """, params).fetchall()
    conn.close()

    rows = list(rows)
    if status == "debtor":
        rows = [r for r in rows if float(r["debts"])-float(r["payments"]) > 0.009]
    elif status == "settled":
        rows = [r for r in rows if abs(float(r["debts"])-float(r["payments"])) <= 0.009]
    return render_template("customers.html", rows=rows, q=q, status=status)


@app.route("/customers/add", methods=["GET", "POST"])
def add_customer():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()
        address = request.form.get("address", "").strip()
        notes = request.form.get("notes", "").strip()
        if not name:
            flash("اسم العميل مطلوب.", "error")
            return redirect(url_for("add_customer"))
        conn = get_db()
        conn.execute("INSERT INTO customers(name,phone,address,notes) VALUES (?,?,?,?)",
                     (name, phone, address, notes))
        conn.commit(); conn.close()
        flash("تمت إضافة العميل بنجاح.", "success")
        return redirect(url_for("customers"))
    return render_template("customer_form.html", customer=None, mode="add")


@app.route("/customer/<int:customer_id>/edit", methods=["GET", "POST"])
def edit_customer(customer_id):
    conn = get_db()
    customer = get_customer_or_404(conn, customer_id)
    if not customer:
        conn.close(); return "العميل غير موجود", 404
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            conn.close(); flash("اسم العميل مطلوب.", "error")
            return redirect(url_for("edit_customer", customer_id=customer_id))
        conn.execute("UPDATE customers SET name=?,phone=?,address=?,notes=? WHERE id=?",
                     (name, request.form.get("phone", "").strip(), request.form.get("address", "").strip(),
                      request.form.get("notes", "").strip(), customer_id))
        conn.commit(); conn.close()
        flash("تم تعديل بيانات العميل.", "success")
        return redirect(url_for("customer_statement", customer_id=customer_id))
    conn.close()
    return render_template("customer_form.html", customer=customer, mode="edit")


@app.route("/debt/add", methods=["GET", "POST"])
def add_debt():
    return transaction_form("debt")


@app.route("/payment/add", methods=["GET", "POST"])
def add_payment():
    return transaction_form("payment")


def transaction_form(tx_type):
    conn = get_db()
    customers_list = conn.execute("SELECT id,name FROM customers ORDER BY name").fetchall()
    selected = request.args.get("customer_id", "")
    if request.method == "POST":
        customer_id = request.form.get("customer_id")
        description = request.form.get("description", "").strip()
        tx_date = request.form.get("tx_date") or datetime.now().strftime("%Y-%m-%d")
        try:
            amount = float(request.form.get("amount", ""))
            if amount <= 0: raise ValueError
        except Exception:
            conn.close(); flash("القيمة المدخلة غير صحيحة.", "error")
            return redirect(request.path)
        if not get_customer_or_404(conn, customer_id):
            conn.close(); flash("اختر عميلاً صحيحاً.", "error")
            return redirect(request.path)
        if tx_type == "payment":
            balance = customer_balance(conn, customer_id)
            if amount > balance + 0.009:
                conn.close(); flash(f"الدفعة أكبر من الرصيد الحالي ({balance:.2f} د.ل).", "error")
                return redirect(request.path)
            description = description or "دفعة"
            payment_method = request.form.get("payment_method", "نقدي")
            conn.execute("""INSERT INTO transactions(customer_id,tx_type,amount,description,tx_date,payment_method)
                            VALUES (?,'payment',?,?,?,?)""",
                         (customer_id, amount, description, tx_date, payment_method))
        else:
            due_date = request.form.get("due_date") or None
            conn.execute("""INSERT INTO transactions(customer_id,tx_type,amount,description,tx_date,due_date)
                            VALUES (?,'debt',?,?,?,?)""",
                         (customer_id, amount, description, tx_date, due_date))
        tx_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.commit(); conn.close()
        flash("تم تسجيل الدين بنجاح." if tx_type=="debt" else "تم تسجيل الدفعة بنجاح.", "success")
        if tx_type == "payment":
            return redirect(url_for("payment_receipt", tx_id=tx_id))
        return redirect(url_for("customer_statement", customer_id=customer_id))
    conn.close()
    template = "debt_form.html" if tx_type=="debt" else "payment_form.html"
    return render_template(template, customers=customers_list, selected=selected,
                           today=datetime.now().strftime("%Y-%m-%d"))


@app.route("/transaction/<int:tx_id>/edit", methods=["GET", "POST"])
def edit_transaction(tx_id):
    conn = get_db()
    tx = conn.execute("SELECT * FROM transactions WHERE id=?", (tx_id,)).fetchone()
    if not tx:
        conn.close(); flash("العملية غير موجودة.", "error"); return redirect(url_for("dashboard"))
    customer = get_customer_or_404(conn, tx["customer_id"])
    if request.method == "POST":
        try:
            amount = float(request.form.get("amount", ""))
            if amount <= 0: raise ValueError
        except Exception:
            conn.close(); flash("القيمة المدخلة غير صحيحة.", "error")
            return redirect(url_for("edit_transaction", tx_id=tx_id))
        tx_date = request.form.get("tx_date") or tx["tx_date"]
        description = request.form.get("description", "").strip()
        if tx["tx_type"] == "payment":
            # balance excluding this payment, so editing cannot exceed available debt.
            bal_without = customer_balance(conn, tx["customer_id"]) + float(tx["amount"])
            if amount > bal_without + 0.009:
                conn.close(); flash(f"الدفعة أكبر من الرصيد المتاح ({bal_without:.2f} د.ل).", "error")
                return redirect(url_for("edit_transaction", tx_id=tx_id))
            conn.execute("UPDATE transactions SET amount=?,description=?,tx_date=?,payment_method=? WHERE id=?",
                         (amount, description or "دفعة", tx_date, request.form.get("payment_method", "نقدي"), tx_id))
        else:
            conn.execute("UPDATE transactions SET amount=?,description=?,tx_date=?,due_date=? WHERE id=?",
                         (amount, description, tx_date, request.form.get("due_date") or None, tx_id))
        conn.commit(); conn.close(); flash("تم تعديل العملية.", "success")
        return redirect(url_for("customer_statement", customer_id=tx["customer_id"]))
    conn.close()
    return render_template("transaction_edit.html", tx=tx, customer=customer)


@app.route("/customer/<int:customer_id>")
def customer_statement(customer_id):
    date_from = request.args.get("date_from", "")
    date_to = request.args.get("date_to", "")
    conn = get_db()
    customer = get_customer_or_404(conn, customer_id)
    if not customer:
        conn.close(); return "العميل غير موجود", 404
    sql = "SELECT * FROM transactions WHERE customer_id=?"
    params = [customer_id]
    if date_from:
        sql += " AND tx_date>=?"; params.append(date_from)
    if date_to:
        sql += " AND tx_date<=?"; params.append(date_to)
    sql += " ORDER BY tx_date ASC,id ASC"
    txs = conn.execute(sql, params).fetchall()

    # Running balance shown for the filtered period, plus actual full balance card.
    running = 0.0; statement = []
    for tx in txs:
        running += float(tx["amount"]) if tx["tx_type"]=="debt" else -float(tx["amount"])
        statement.append(dict(id=tx["id"], tx_no=f"{tx['id']:06d}", tx_date=tx["tx_date"],
            tx_type=tx["tx_type"], description=tx["description"] or ("دين" if tx["tx_type"]=="debt" else "دفعة"),
            debt=float(tx["amount"]) if tx["tx_type"]=="debt" else 0,
            payment=float(tx["amount"]) if tx["tx_type"]=="payment" else 0,
            balance=running, payment_method=tx["payment_method"] or "", due_date=tx["due_date"] or ""))
    full_balance = customer_balance(conn, customer_id)
    conn.close()
    return render_template("statement.html", customer=customer, statement=statement,
                           period_balance=running, balance=full_balance, date_from=date_from, date_to=date_to)


@app.route("/payment/<int:tx_id>/receipt")
def payment_receipt(tx_id):
    conn = get_db()
    tx = conn.execute("""SELECT t.*, c.name,c.phone,c.address FROM transactions t
                         JOIN customers c ON c.id=t.customer_id WHERE t.id=? AND t.tx_type='payment'""", (tx_id,)).fetchone()
    if not tx:
        conn.close(); return "الإيصال غير موجود", 404
    balance = customer_balance(conn, tx["customer_id"])
    conn.close()
    return render_template("receipt.html", tx=tx, balance=balance)


@app.route("/transaction/<int:tx_id>/delete", methods=["POST"])
def delete_transaction(tx_id):
    conn = get_db(); tx = conn.execute("SELECT customer_id FROM transactions WHERE id=?", (tx_id,)).fetchone()
    if not tx:
        conn.close(); flash("العملية غير موجودة.", "error"); return redirect(url_for("dashboard"))
    customer_id = tx["customer_id"]
    conn.execute("DELETE FROM transactions WHERE id=?", (tx_id,)); conn.commit(); conn.close()
    flash("تم حذف العملية.", "success")
    return redirect(url_for("customer_statement", customer_id=customer_id))


@app.route("/reports")
def reports():
    date_from = request.args.get("date_from", datetime.now().strftime("%Y-%m-01"))
    date_to = request.args.get("date_to", datetime.now().strftime("%Y-%m-%d"))
    conn = get_db()
    summary = conn.execute("""
      SELECT COALESCE(SUM(CASE WHEN tx_type='debt' THEN amount ELSE 0 END),0) debts,
             COALESCE(SUM(CASE WHEN tx_type='payment' THEN amount ELSE 0 END),0) payments,
             COUNT(*) tx_count
      FROM transactions WHERE tx_date BETWEEN ? AND ?
    """, (date_from, date_to)).fetchone()
    rows = conn.execute("""
      SELECT t.*,c.name FROM transactions t JOIN customers c ON c.id=t.customer_id
      WHERE t.tx_date BETWEEN ? AND ? ORDER BY t.tx_date DESC,t.id DESC
    """, (date_from, date_to)).fetchall()
    conn.close()
    return render_template("reports.html", date_from=date_from,date_to=date_to,summary=summary,rows=rows)


@app.route("/settings")
def settings():
    backups = sorted(BACKUP_DIR.glob("*.db"), reverse=True)
    return render_template("settings.html", backups=backups)


@app.route("/backup/create", methods=["POST"])
def create_backup():
    init_db(); stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
    shutil.copy2(DB_PATH, BACKUP_DIR/f"debts_backup_{stamp}.db")
    flash("تم إنشاء النسخة الاحتياطية بنجاح.", "success"); return redirect(url_for("settings"))


@app.route("/backup/download")
def download_backup():
    init_db(); stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
    temp=BACKUP_DIR/f"debts_backup_{stamp}.db"; shutil.copy2(DB_PATH,temp)
    return send_file(temp, as_attachment=True, download_name=temp.name)


@app.route("/backup/restore", methods=["POST"])
def restore_backup():
    file=request.files.get("backup_file")
    if not file or not file.filename:
        flash("اختر ملف نسخة احتياطية أولاً.", "error"); return redirect(url_for("settings"))
    if not file.filename.lower().endswith(".db"):
        flash("الملف غير صالح. يجب أن يكون بصيغة .db", "error"); return redirect(url_for("settings"))
    temp=BACKUP_DIR/"restore_temp.db"; file.save(temp)
    try:
        test=sqlite3.connect(temp); tables={r[0] for r in test.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}; test.close()
        if not {"customers","transactions"}.issubset(tables): raise ValueError
        if DB_PATH.exists(): shutil.copy2(DB_PATH, BACKUP_DIR/f"before_restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db")
        shutil.copy2(temp,DB_PATH); flash("تمت استعادة النسخة الاحتياطية بنجاح.", "success")
    except Exception:
        flash("تعذر استعادة النسخة: الملف ليس نسخة صحيحة للبرنامج.", "error")
    finally:
        if temp.exists(): temp.unlink()
    return redirect(url_for("settings"))


def start_server(data_dir=None):
    if data_dir:
        global DATA_DIR, DB_PATH, BACKUP_DIR
        DATA_DIR = Path(str(data_dir))
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        DB_PATH = DATA_DIR / "debts.db"
        BACKUP_DIR = DATA_DIR / "backups"
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False, threaded=True)

if __name__ == "__main__":
    start_server()
