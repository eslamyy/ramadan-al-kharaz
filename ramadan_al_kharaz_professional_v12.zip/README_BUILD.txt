Ramadan Al Kharaz Center - Professional V11

Implemented:
- New professional invoice print/preview layout based on the approved design.
- Real WhatsApp QR code linked to 0910284368 (wa.me/218910284368).
- Warranty text: يسري الضمان على خدمة المحرك لا يشمل القطع الكهربائية.
- Separate Save Draft button.
- New Sell and Approve Invoice button.
- Inventory is deducted only when Sell and Approve is pressed.
- Editing a sold invoice safely restores old quantities and deducts revised quantities.
- Deleting a sold invoice restores its inventory quantities.
- Sequential invoice numbers and previous permissions/login/backup features retained.
