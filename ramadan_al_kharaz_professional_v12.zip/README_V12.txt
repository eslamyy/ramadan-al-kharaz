Ramadan Al Kharaz Center - V12
- Full invoice preview fitted to mobile screen without left/right clipping.
- A4 print layout retained.
- Invoice table widths and wrapping improved.
- Header/logo/vehicle-brand layout tightened.
- Bottom navigation lifted with safe spacing.
- WhatsApp QR, warranty wording, invoice sale/approval, automatic inventory deduction,
  sequential invoice numbers, permissions and backup features retained from V11.
